
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.aquavie.tacz_delta.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.aquavie.tacz_delta.network.ZzaijuMessage;
import net.aquavie.tacz_delta.network.Zd2Message;
import net.aquavie.tacz_delta.network.PaobingMessage;
import net.aquavie.tacz_delta.TaczDeltaMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class TaczDeltaModKeyMappings {
	public static final KeyMapping ZD_2 = new KeyMapping("key.tacz_delta.zd_2", GLFW.GLFW_KEY_UNKNOWN, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				ZD_2_LASTPRESS = System.currentTimeMillis();
			} else if (isDownOld != isDown && !isDown) {
				int dt = (int) (System.currentTimeMillis() - ZD_2_LASTPRESS);
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new Zd2Message(1, dt));
				Zd2Message.pressAction(Minecraft.getInstance().player, 1, dt);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping PAOBING = new KeyMapping("key.tacz_delta.paobing", GLFW.GLFW_KEY_UNKNOWN, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				PAOBING_LASTPRESS = System.currentTimeMillis();
			} else if (isDownOld != isDown && !isDown) {
				int dt = (int) (System.currentTimeMillis() - PAOBING_LASTPRESS);
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new PaobingMessage(1, dt));
				PaobingMessage.pressAction(Minecraft.getInstance().player, 1, dt);
			}
			isDownOld = isDown;
		}
	};
	public static final KeyMapping ZZAIJU = new KeyMapping("key.tacz_delta.zzaiju", GLFW.GLFW_KEY_UNKNOWN, "key.categories.misc") {
		private boolean isDownOld = false;

		@Override
		public void setDown(boolean isDown) {
			super.setDown(isDown);
			if (isDownOld != isDown && isDown) {
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new ZzaijuMessage(0, 0));
				ZzaijuMessage.pressAction(Minecraft.getInstance().player, 0, 0);
			}
			isDownOld = isDown;
		}
	};
	private static long ZD_2_LASTPRESS = 0;
	private static long PAOBING_LASTPRESS = 0;

	@SubscribeEvent
	public static void registerKeyMappings(RegisterKeyMappingsEvent event) {
		event.register(ZD_2);
		event.register(PAOBING);
		event.register(ZZAIJU);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onClientTick(TickEvent.ClientTickEvent event) {
			if (Minecraft.getInstance().screen == null) {
				ZD_2.consumeClick();
				PAOBING.consumeClick();
				ZZAIJU.consumeClick();
			}
		}
	}
}

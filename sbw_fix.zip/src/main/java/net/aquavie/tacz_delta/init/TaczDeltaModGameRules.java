
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.aquavie.tacz_delta.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TaczDeltaModGameRules {
	public static final GameRules.Key<GameRules.IntegerValue> BOOMNUM = GameRules.register("boomnum", GameRules.Category.DROPS, GameRules.IntegerValue.create(20));
}


/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.aquavie.tacz_delta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.aquavie.tacz_delta.world.inventory.ZaijuMenu;
import net.aquavie.tacz_delta.TaczDeltaMod;

public class TaczDeltaModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, TaczDeltaMod.MODID);
	public static final RegistryObject<MenuType<ZaijuMenu>> ZAIJU = REGISTRY.register("zaiju", () -> IForgeMenuType.create(ZaijuMenu::new));
}

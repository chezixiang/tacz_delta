
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.aquavie.tacz_delta.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.aquavie.tacz_delta.item.LeizhiItem;
import net.aquavie.tacz_delta.TaczDeltaMod;

public class TaczDeltaModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TaczDeltaMod.MODID);
	public static final RegistryObject<Item> LEIZHI = REGISTRY.register("leizhi", () -> new LeizhiItem());
	// Start of user code block custom items
	// End of user code block custom items
}

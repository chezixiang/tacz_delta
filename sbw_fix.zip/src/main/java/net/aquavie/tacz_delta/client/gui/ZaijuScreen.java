package net.aquavie.tacz_delta.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.aquavie.tacz_delta.world.inventory.ZaijuMenu;
import net.aquavie.tacz_delta.network.ZaijuButtonMessage;
import net.aquavie.tacz_delta.TaczDeltaMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class ZaijuScreen extends AbstractContainerScreen<ZaijuMenu> {
	private final static HashMap<String, Object> guistate = ZaijuMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Button button_yx100zhu_zhan_tan_ke;
	Button button_lav150_lun_shi_bu_bing_zhan_che;
	Button button_bmp2_lu_dai_shi_bu_bing_zhan_che;
	Button button_ah6_xiao_niao_zhi_sheng_ji;

	public ZaijuScreen(ZaijuMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 256;
		this.imageHeight = 106;
	}

	private static final ResourceLocation texture = new ResourceLocation("tacz_delta:textures/screens/zaiju.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		guiGraphics.blit(texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.tacz_delta.zaiju.label_qing_xuan_ze_zai_ju"), 105, -30, -10027009, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.tacz_delta.zaiju.label_jing_gao_zhe_bu_hui_zan_ting_you_xi_ji_shi_zai_dan_ren_shi_jie_zhong"), 67, 118, -52429, false);
	}

	@Override
	public void init() {
		super.init();
		button_yx100zhu_zhan_tan_ke = Button.builder(Component.translatable("gui.tacz_delta.zaiju.button_yx100zhu_zhan_tan_ke"), e -> {
			if (true) {
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new ZaijuButtonMessage(0, x, y, z));
				ZaijuButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 21, this.topPos + 13, 77, 20).build();
		guistate.put("button:button_yx100zhu_zhan_tan_ke", button_yx100zhu_zhan_tan_ke);
		this.addRenderableWidget(button_yx100zhu_zhan_tan_ke);
		button_lav150_lun_shi_bu_bing_zhan_che = Button.builder(Component.translatable("gui.tacz_delta.zaiju.button_lav150_lun_shi_bu_bing_zhan_che"), e -> {
			if (true) {
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new ZaijuButtonMessage(1, x, y, z));
				ZaijuButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 136, this.topPos + 13, 98, 20).build();
		guistate.put("button:button_lav150_lun_shi_bu_bing_zhan_che", button_lav150_lun_shi_bu_bing_zhan_che);
		this.addRenderableWidget(button_lav150_lun_shi_bu_bing_zhan_che);
		button_bmp2_lu_dai_shi_bu_bing_zhan_che = Button.builder(Component.translatable("gui.tacz_delta.zaiju.button_bmp2_lu_dai_shi_bu_bing_zhan_che"), e -> {
			if (true) {
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new ZaijuButtonMessage(2, x, y, z));
				ZaijuButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 137, this.topPos + 57, 93, 20).build();
		guistate.put("button:button_bmp2_lu_dai_shi_bu_bing_zhan_che", button_bmp2_lu_dai_shi_bu_bing_zhan_che);
		this.addRenderableWidget(button_bmp2_lu_dai_shi_bu_bing_zhan_che);
		button_ah6_xiao_niao_zhi_sheng_ji = Button.builder(Component.translatable("gui.tacz_delta.zaiju.button_ah6_xiao_niao_zhi_sheng_ji"), e -> {
			if (true) {
				TaczDeltaMod.PACKET_HANDLER.sendToServer(new ZaijuButtonMessage(3, x, y, z));
				ZaijuButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 21, this.topPos + 57, 77, 20).build();
		guistate.put("button:button_ah6_xiao_niao_zhi_sheng_ji", button_ah6_xiao_niao_zhi_sheng_ji);
		this.addRenderableWidget(button_ah6_xiao_niao_zhi_sheng_ji);
	}
}

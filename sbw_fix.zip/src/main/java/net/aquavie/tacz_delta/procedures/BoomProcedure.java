package net.aquavie.tacz_delta.procedures;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.aquavie.tacz_delta.network.TaczDeltaModVariables;
import net.aquavie.tacz_delta.TaczDeltaMod;

public class BoomProcedure {
	public static void execute(LevelAccessor world, double x, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).boom_count > 0) {
			TaczDeltaMod.queueServerWork(40, () -> {
				{
					double _setval = x + Mth.nextInt(RandomSource.create(), -48, 48);
					entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.x_temp = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = z + Mth.nextInt(RandomSource.create(), -48, 48);
					entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.z_temp = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).boom_count - 1;
					entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.boom_count = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				if (world instanceof Level _level && !_level.isClientSide())
					_level.explode(entity, ((entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).x_temp),
							(world.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) (entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).x_temp,
									(int) (entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).z_temp)),
							((entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).z_temp), (float) 10.2, Level.ExplosionInteraction.TNT);
				BoomProcedure.execute(world, x, z, entity);
			});
		} else {
			{
				boolean _setval = true;
				entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.is_not_boom = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}

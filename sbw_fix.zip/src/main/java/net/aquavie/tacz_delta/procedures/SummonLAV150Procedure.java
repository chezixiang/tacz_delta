package net.aquavie.tacz_delta.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.aquavie.tacz_delta.TaczDeltaMod;

public class SummonLAV150Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plr ? _plr.experienceLevel : 0) >= 10) {
			if (entity instanceof Player _player)
				_player.closeContainer();
			if (entity instanceof Player _player)
				_player.giveExperienceLevels(-(10));
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u8F7D\u5177\u5C06\u57285\u79D2\u540E\u9001\u8FBE\u5F53\u524D\u7AD9\u7ACB\u4F4D\u7F6E\uFF0C\u8BF7\u6CE8\u610F\u8EB2\u907F"), false);
			TaczDeltaMod.queueServerWork(100, () -> {
				{
					Entity _ent = entity;
					if (!_ent.level().isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
								_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), ("/summon superbwarfare:lav_150 " + x + " " + (y + 1) + " " + z + " {Energy:5000000}"));
					}
				}
			});
		} else {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u7ECF\u9A8C\u4E0D\u8DB3\uFF01"), false);
		}
	}
}

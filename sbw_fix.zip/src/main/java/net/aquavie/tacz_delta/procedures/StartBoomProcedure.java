package net.aquavie.tacz_delta.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.client.Minecraft;

import net.aquavie.tacz_delta.network.TaczDeltaModVariables;
import net.aquavie.tacz_delta.init.TaczDeltaModItems;
import net.aquavie.tacz_delta.init.TaczDeltaModGameRules;
import net.aquavie.tacz_delta.TaczDeltaMod;

import java.util.Calendar;

public class StartBoomProcedure {
	public static void execute(LevelAccessor world, double x, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).is_not_boom) {
			{
				boolean _setval = false;
				entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.is_not_boom = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (world.getLevelData().getGameRules().getInt(TaczDeltaModGameRules.BOOMNUM));
				entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.boom_count = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if ((entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new TaczDeltaModVariables.PlayerVariables())).boom_count <= 0) {
				{
					double _setval = 20;
					entity.getCapability(TaczDeltaModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.boom_count = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				world.getLevelData().getGameRules().getRule(TaczDeltaModGameRules.BOOMNUM).set(20, world.getServer());
			}
			if (!(new Object() {
				public boolean checkGamemode(Entity _ent) {
					if (_ent instanceof ServerPlayer _serverPlayer) {
						return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
					} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
						return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null
								&& Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
					}
					return false;
				}
			}.checkGamemode(entity))) {
				if (!(entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(TaczDeltaModItems.LEIZHI.get())) : false)
						&& !((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == TaczDeltaModItems.LEIZHI.get())) {
					TaczDeltaMod.LOGGER.warn((entity.getDisplayName().getString() + "\u6D89\u5ACC\u4F5C\u5F0A\uFF0C\u88AB\u7CFB\u7EDF\u51FB\u6740\uFF0C\u65F6\u95F4\uFF1A" + Calendar.getInstance().getTime().toString()));
					if (!world.isClientSide() && world.getServer() != null)
						world.getServer().getPlayerList().broadcastSystemMessage(Component.literal((entity.getDisplayName().getString() + "\u6D89\u5ACC\u4F5C\u5F0A\uFF0C\u88AB\u7CFB\u7EDF\u51FB\u6740")), false);
					if (!entity.level().isClientSide())
						entity.discard();
					return;
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == TaczDeltaModItems.LEIZHI.get()) {
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack = new ItemStack(Blocks.AIR).copy();
						_setstack.setCount(1);
						_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
				} else {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove = new ItemStack(TaczDeltaModItems.LEIZHI.get());
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
				}
			}
			BoomProcedure.execute(world, x, z, entity);
		} else {
			if (entity instanceof Player _player && !_player.level().isClientSide())
				_player.displayClientMessage(Component.literal("\u5DF2\u7ECF\u6709\u9635\u5730\u652F\u63F4\u6280\u80FD\u6B63\u5728\u4F7F\u7528\u4E2D"), false);
		}
	}
}

package net.aquavie.tacz_delta.command;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.common.util.FakePlayerFactory;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.Commands;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import net.minecraft.core.Direction;

import net.aquavie.tacz_delta.procedures.BoosthealthProcedure;
import net.aquavie.tacz_delta.procedures.FixProcedure;

@Mod.EventBusSubscriber
public class DaltaCommand {

    @SubscribeEvent
    public static void registerCommand(RegisterCommandsEvent event) {
        event.getDispatcher().register(
            Commands.literal("dalta")
                .requires(s -> s.hasPermission(2))
                
                // /dalta test set_health 命令
                .then(Commands.literal("test")
                    .then(Commands.literal("set_health")
                        .then(Commands.argument("entity", EntityArgument.entity())
                        .then(Commands.argument("num", DoubleArgumentType.doubleArg())
                            .executes(arguments -> {
                                CommandSourceStack source = arguments.getSource();
                                Entity targetEntity = EntityArgument.getEntity(arguments, "entity");
                                double num = DoubleArgumentType.getDouble(arguments, "num");
                                
                                Entity sourceEntity = source.getEntity();
                                Level world = source.getLevel();
                                
                                if (sourceEntity == null && world instanceof ServerLevel serverLevel) {
                                    sourceEntity = FakePlayerFactory.getMinecraft(serverLevel);
                                }
                                
                                BoosthealthProcedure.execute(targetEntity, sourceEntity, num);
                                return 1;
                            })
                        )
                    )
                )
                
                // /dalta fix 命令
                .then(Commands.literal("fix")
                    .executes(arguments -> {
                        CommandSourceStack source = arguments.getSource();
                        Level world = source.getLevel();
                        
                        double x = source.getPosition().x();
                        double y = source.getPosition().y();
                        double z = source.getPosition().z();
                        
                        Entity entity = source.getEntity();
                        if (entity == null && world instanceof ServerLevel serverLevel) {
                            entity = FakePlayerFactory.getMinecraft(serverLevel);
                        }
                        
                        Direction direction = Direction.DOWN;
                        if (entity != null) {
                            direction = entity.getDirection();
                        }
                        
                        FixProcedure.execute(entity);
                        return 1;
                    })
                )
        ));
    }
}

package net.aquavie.tacz_delta.network;

import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.aquavie.tacz_delta.world.inventory.ZaijuMenu;
import net.aquavie.tacz_delta.procedures.SummonYX100Procedure;
import net.aquavie.tacz_delta.procedures.SummonLAV150Procedure;
import net.aquavie.tacz_delta.procedures.SummonBMP2Procedure;
import net.aquavie.tacz_delta.procedures.SummonAH6Procedure;
import net.aquavie.tacz_delta.TaczDeltaMod;

import java.util.function.Supplier;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ZaijuButtonMessage {
	private final int buttonID, x, y, z;

	public ZaijuButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public ZaijuButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(ZaijuButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(ZaijuButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> {
			Player entity = context.getSender();
			int buttonID = message.buttonID;
			int x = message.x;
			int y = message.y;
			int z = message.z;
			handleButtonAction(entity, buttonID, x, y, z);
		});
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		HashMap guistate = ZaijuMenu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			SummonYX100Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			SummonLAV150Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			SummonBMP2Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 3) {

			SummonAH6Procedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		TaczDeltaMod.addNetworkMessage(ZaijuButtonMessage.class, ZaijuButtonMessage::buffer, ZaijuButtonMessage::new, ZaijuButtonMessage::handler);
	}
}
